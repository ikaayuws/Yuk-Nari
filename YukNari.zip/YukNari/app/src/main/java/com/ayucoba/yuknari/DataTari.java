package com.ayucoba.yuknari;

import java.util.ArrayList;

public class DataTari {
    private static String[] namaTari = {
            "Tari Jaipong",
            "Tari Kecak",
            "Tari Remong",
            "Tari Pendet",
            "Tari Gambyong",
            "Tari Serimpi",
            "Tari Yapong",
            "Tari Saman",
            "Tari Piring",
            "Tari Tor Tor"
    };

    private static String[] detailTari = {
            "Tarian ini dikenal dengan gerakan yang dinamis dan atraktif karena berasal dari gabungan pencak silat, tari ronggeng dan tari ketuk tilu. Biasanya tarian ini dibawakan secara per orangan atau grup dan ditampilkan saat penyambutan tamu besar hingga festival budaya.",
            "Tari kecak menampilkan drama tari dari cerita Ramayana ini menjadi salah satu daya tarik wisatawan. Tari Kecak disebut juga dengan tari Sang Hyang yang dilakukan saat upacara keagamaan.",
            "Tari remong atau yang biasa disebut dengan tari remo adalah tarian yang menggambarkan seorang pangeran yang berjuang di medan perang. Tarian ini sering ditampilkan sebagai pengantar pertunjukan dalam pergelaran kesenian Ludruk atau tarian selamat datang untuk menyambut tamu. Umumnya, tari ini dibawakan penari laki-laki dengan gerakan yang gagah berani.",
            "Tari pendet ditampilkan sebagai tarian selamat datang atau tarian penyambutan. Tari pendet biasa dibawakan penari wanita dengan membawa mangkuk kecil berisi berbagai macam bunga yang menjadi ciri khasnya. Awalnya, tari pendet merupakan tarian yang menjadi bagian dari upacara di pura sebagai ungkapan rasa syukur dan penghormatan dalam menyambut kehadiran para dewata yang turun dari khayangan.",
            "Masyarakat Jawa dikenal dengan kelembutan dan keluwesannya. Hal tersebut digambarkan dalam sebuah kesenian, yaitu tari gambyong. Tarian ini dibawakan beberapa penari wanita dengan gerakan yang anggun dan indah. Di masa Kraton Surakarta, tari gambyong sering dijadikan sebagai tarian hiburan dan tarian penyambutan tamu kehormatan. Namun seiring dengan perkembangan zaman, tarian ini juga.",
            "Tarian klasik ini bersifat sakral yang menggambarkan kesopanan dan kelemahlembutan. Hal tersebut dapat dilihat dari gerakannya yang pelan dan lemah lembut. Dulu tarian ini hanya ditampilkan di lingkungan Keraton untuk acara kenegaraan dan peringatan kenaikan tahta Sultan. Karena sifatnya yang sakral, penarinya juga sudah dipilih oleh keluarga kerajaan. Namun setelah Kerajaan Mataram pecah, tarian ini mulai mengalami perubahan dalam segi gerakan meskipun inti dari tarian ini masih sama.",
            "Jenis tarian kontemporer ini melambangkan suka cita dan pergaulan masyarakat Betawi. Gerakan dalam tarian ini sederhana namun sangat dinamis. Para penari menari dengan ekspresi gembira dengan memainkan kaki dan tangan secara bergantian. Tarian ini memiliki gerakan sangat bervariatif karena tari Yapong merupakan tarian kontemporer. Tarian ini terus berkembang dengan berbagai kreasi dalam setiap pertunjukannya.",
            "Tarian yang dibawakan sekelompok orang yang jumlahnya ganjil ini sudah melenggang hingga ke mancanegara. Keunikan tarian ini terlihat dari penggunaan tangan penari untuk menciptakan suara-suara yang padu. Jika kebanyakan tari tradisional lain penarinya bergerak bebas, tari saman dibawakan penarinya dengan cara duduk. Selain menggunakan gerakan tangan, para penari juga berbagi tugas, ada yang mengaum, menyanyikan lagu, dan lain sebagainya.",
            "Tari ini disebut unik karena menggunakan properti berupa piring dalam tariannya. Piring-piring yang digunakan para penari tersebut diayun dengan gerakan-gerakan yang cepat namun teratur. Tari tradisional dari Minangkabau ini dibawakan oleh beberapa penari yang membawa dua piring di setiap telapak tangannya.",
            "Tari Tor-Tor bukan hanyalah sekedar tarian, namun tarian ini memiliki arti dan juga ciri khas. Tarian ini selalu disajikan bersama musik gondang dan tidak bisa dipisahkan. Secara fisik, tari Tor-Tor hanyalah sekedar tarian, namun pada kenyataannya setiap gerakan merupakan sebuah media komunikasi yang ditujukan untuk menghasilkan interaksi dengan partisipan acara. Selai gerakannya yang mengandung makna, tari tor-tor juga terdapat prosesi Tua ni Gondang. Prosesi tersebut merupakan salah satu proses penyampaian permintaan khusus dari tuan rumah kepada penabuh gondang dengan kata-kata yang sopan dan santun."
    };

    private static String[] asalTari = {
            "Jawa Barat",
            "Bali",
            "Jawa Timur",
            "Bali",
            "Jawa Tengah",
            "Yogyakarta",
            "Jakarta",
            "Aceh",
            "Sumatera Barat",
            "Sumatera Utara"
    };

    private static int[] gambarTari = {
            R.drawable.tari_jaipong,
            R.drawable.tari_kecak,
            R.drawable.tari_remong,
            R.drawable.tari_pendet,
            R.drawable.tari_gambyong,
            R.drawable.tari_serimpi,
            R.drawable.tari_yapong,
            R.drawable.tari_saman,
            R.drawable.tari_piring,
            R.drawable.tari_tortor
    };

    static ArrayList<Tari> getListData() {
        ArrayList<Tari> list = new ArrayList<>();
        for (int position = 0; position < namaTari.length; position++) {
            Tari tari = new Tari();
            tari.setNama_tari(namaTari[position]);
            tari.setDetail_tari(detailTari[position]);
            tari.setPhoto(gambarTari[position]);
            tari.setAsal(asalTari[position]);
            list.add(tari);
        }
        return list;
    }
}

package com.ayucoba.yuknari;

import com.ayucoba.yuknari.Tari;

public interface OnItemClickCallback {
    void onItemClicked(Tari tari);
}

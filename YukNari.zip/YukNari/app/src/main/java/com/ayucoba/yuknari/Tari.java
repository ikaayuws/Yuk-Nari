package com.ayucoba.yuknari;

import android.os.Parcel;
import android.os.Parcelable;

public class Tari implements Parcelable {
    private String nama_tari;
    private String detail_tari;
    private int photo;
    private String asal;

    public Tari() {

    }

    public String getNama_tari() {
        return nama_tari;
    }

    public void setNama_tari(String nama_tari) {
        this.nama_tari = nama_tari;
    }

    public String getDetail_tari() {
        return detail_tari;
    }

    public void setDetail_tari(String detail_tari) {
        this.detail_tari = detail_tari;
    }

    public int getPhoto() {
        return photo;
    }

    public void setPhoto(int photo) {
        this.photo = photo;
    }

    public String getAsal() {
        return asal;
    }

    public void setAsal(String asal) {
        this.asal = asal;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(nama_tari);
        parcel.writeString(detail_tari);
        parcel.writeInt(photo);
        parcel.writeString(asal);
    }

    protected Tari(Parcel in) {
        nama_tari = in.readString();
        detail_tari = in.readString();
        photo = in.readInt();
        asal = in.readString();
    }

    public static final Creator<Tari> CREATOR = new Creator<Tari>() {
        @Override
        public Tari createFromParcel(Parcel in) {
            return new Tari(in);
        }

        @Override
        public Tari[] newArray(int size) {
            return new Tari[size];
        }
    };
}

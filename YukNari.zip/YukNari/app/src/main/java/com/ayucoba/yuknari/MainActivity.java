package com.ayucoba.yuknari;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.ayucoba.yuknari.ListTariAdapter;
import com.ayucoba.yuknari.OnItemClickCallback;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {
    private RecyclerView r_tari;
    private ArrayList<Tari> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        r_tari = findViewById(R.id.r_tari);
        r_tari.setHasFixedSize(true);

        list.addAll(DataTari.getListData());
        showRecyclerList();
    }
    private void showRecyclerList(){
        r_tari.setLayoutManager(new LinearLayoutManager(this));
        ListTariAdapter listTariAdapter = new ListTariAdapter(list);
        r_tari.setAdapter(listTariAdapter);

        listTariAdapter.setOnItemClickCallback(new OnItemClickCallback() {
            @Override
            public void onItemClicked(Tari tari) {
                Intent moveIntent1 = new Intent(MainActivity.this, DetailTari.class);
                moveIntent1.putExtra(DetailTari.ITEM_EXTRA, tari);
                startActivity(moveIntent1);
            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.main_activity_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.about_id) {
            Intent moveIntent = new Intent(MainActivity.this, AboutDetail.class);
            startActivity(moveIntent);
        }
        return super.onOptionsItemSelected(item);
    }
}
